package FilePack;

import java.io.FileOutputStream;

public class FileExmp 
  {
	public void createFile() throws Exception
	
	{ 
		String name = "hi rahul...";
		FileOutputStream fout= new FileOutputStream("java.txt");
		byte b[]=name.getBytes();
		fout.write(b);
		System.out.println("sucess");
	}
	
	public static void main(String[] args) throws Exception
	{
		FileExmp fe = new FileExmp();
		fe.createFile();
		
		
	}

}

