package FilePack;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Input 
  {
	public void fetchFile() throws Exception
	
	{ 
		
		FileInputStream fin= new FileInputStream("java.txt");
		int a;
		System.out.println(" ");
		while((a=fin.read())!=-1)
		{
			System.out.print( (char) a);	
			System.out.println( (int) a);  //for ascii values
		}
		fin.close();
	}
	
	public static void main(String[] args) throws Exception
	{
		Input it = new Input();
		it.fetchFile();
		
		
	}

}

